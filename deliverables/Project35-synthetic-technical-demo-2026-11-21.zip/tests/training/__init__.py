"""Training and tracking tests."""
